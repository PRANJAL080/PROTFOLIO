"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Song } from "@/lib/data";

type Props = {
  song?: Song;
  mode: "create" | "edit";
};

export function SongForm({ song, mode }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    title: song?.title || "",
    slug: song?.slug || "",
    genre: song?.genre || "Devotional",
    mood: song?.mood || "",
    description: song?.description || "",
    lyrics: song?.lyrics || "",
    sunoUrl: song?.sunoUrl || "",
    trackNumber: song?.trackNumber?.toString() || "",
    licenseStatus: song?.licenseStatus || "Available",
    licenseAvailable: song?.licenseAvailable ?? true,
    featured: song?.featured ?? false,
    published: song?.published ?? true,
  });

  function update(field: string, value: string | boolean) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    const payload = {
      title: form.title.trim(),
      slug: form.slug.trim() || undefined,
      genre: form.genre.trim(),
      mood: form.mood.trim(),
      description: form.description.trim(),
      lyrics: form.lyrics.trim() || null,
      sunoUrl: form.sunoUrl.trim() || null,
      trackNumber: form.trackNumber ? Number(form.trackNumber) : undefined,
      licenseStatus: form.licenseStatus,
      licenseAvailable: form.licenseAvailable,
      featured: form.featured,
      published: form.published,
    };

    try {
      const url =
        mode === "create" ? "/api/songs" : `/api/songs/${song!.id}`;
      const res = await fetch(url, {
        method: mode === "create" ? "POST" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong");
        setLoading(false);
        return;
      }
      router.push("/admin/songs");
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  }

  async function handleDelete() {
    if (!song || !confirm(`Delete "${song.title}" from the playlist?`)) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/songs/${song.id}`, { method: "DELETE" });
      if (!res.ok) {
        setError("Failed to delete");
        setLoading(false);
        return;
      }
      router.push("/admin/songs");
      router.refresh();
    } catch {
      setError("Network error");
      setLoading(false);
    }
  }

  const inputClass =
    "w-full bg-transparent border border-white/15 rounded-sm px-4 py-2.5 text-[#F8F4EC] text-sm focus:outline-none focus:border-[#C9A84C]/60 transition-colors";
  const labelClass = "text-xs tracking-widest uppercase text-[#A8A29E] block mb-1.5";

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      {error && (
        <div className="border border-red-500/30 bg-red-500/10 text-red-300 text-sm px-4 py-3 rounded-sm">
          {error}
        </div>
      )}

      <div className="space-y-2">
        <label htmlFor="title" className={labelClass}>
          Title (Hindi or English) *
        </label>
        <input
          id="title"
          required
          value={form.title}
          onChange={(e) => update("title", e.target.value)}
          className={inputClass}
          placeholder="जयति जय नारायणा"
        />
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label htmlFor="genre" className={labelClass}>
            Genre
          </label>
          <input
            id="genre"
            value={form.genre}
            onChange={(e) => update("genre", e.target.value)}
            className={inputClass}
            placeholder="Devotional, Romantic..."
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="mood" className={labelClass}>
            Mood
          </label>
          <input
            id="mood"
            value={form.mood}
            onChange={(e) => update("mood", e.target.value)}
            className={inputClass}
            placeholder="Reverent, Peaceful"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="sunoUrl" className={labelClass}>
          Suno / Audio URL
        </label>
        <input
          id="sunoUrl"
          type="url"
          value={form.sunoUrl}
          onChange={(e) => update("sunoUrl", e.target.value)}
          className={inputClass}
          placeholder="https://suno.com/song/..."
        />
        <p className="text-[#A8A29E]/50 text-xs">
          Optional. Link to AI-generated audio presentation (e.g. Suno).
        </p>
      </div>

      <div className="space-y-2">
        <label htmlFor="description" className={labelClass}>
          Short description
        </label>
        <textarea
          id="description"
          rows={3}
          value={form.description}
          onChange={(e) => update("description", e.target.value)}
          className={inputClass + " resize-none"}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="lyrics" className={labelClass}>
          Full lyrics
        </label>
        <textarea
          id="lyrics"
          rows={10}
          value={form.lyrics}
          onChange={(e) => update("lyrics", e.target.value)}
          className={inputClass + " resize-y font-serif"}
          placeholder="Paste full lyrics here..."
        />
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label htmlFor="trackNumber" className={labelClass}>
            Track number (playlist order)
          </label>
          <input
            id="trackNumber"
            type="number"
            min={1}
            value={form.trackNumber}
            onChange={(e) => update("trackNumber", e.target.value)}
            className={inputClass}
            placeholder="Auto"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="licenseStatus" className={labelClass}>
            License status
          </label>
          <select
            id="licenseStatus"
            value={form.licenseStatus}
            onChange={(e) => update("licenseStatus", e.target.value)}
            className={inputClass + " bg-[#0A0A0A]"}
          >
            <option value="Available">Available</option>
            <option value="By Enquiry">By Enquiry</option>
            <option value="Exclusive">Exclusive</option>
            <option value="Unavailable">Unavailable</option>
            <option value="Coming Soon">Coming Soon</option>
          </select>
        </div>
      </div>

      <div className="flex flex-wrap gap-6 text-sm">
        <label className="flex items-center gap-2 text-[#A8A29E] cursor-pointer">
          <input
            type="checkbox"
            checked={form.published}
            onChange={(e) => update("published", e.target.checked)}
            className="accent-[#C9A84C]"
          />
          Published (show on playlist)
        </label>
        <label className="flex items-center gap-2 text-[#A8A29E] cursor-pointer">
          <input
            type="checkbox"
            checked={form.featured}
            onChange={(e) => update("featured", e.target.checked)}
            className="accent-[#C9A84C]"
          />
          Featured on homepage
        </label>
        <label className="flex items-center gap-2 text-[#A8A29E] cursor-pointer">
          <input
            type="checkbox"
            checked={form.licenseAvailable}
            onChange={(e) => update("licenseAvailable", e.target.checked)}
            className="accent-[#C9A84C]"
          />
          Open for licensing
        </label>
      </div>

      <div className="flex flex-wrap gap-3 pt-4 border-t border-white/10">
        <button
          type="submit"
          disabled={loading}
          className="px-6 py-2.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium rounded-sm hover:bg-[#A68B3D] transition-colors disabled:opacity-50"
        >
          {loading
            ? "Saving..."
            : mode === "create"
              ? "Add to Playlist"
              : "Save Changes"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/admin/songs")}
          className="px-6 py-2.5 border border-white/15 text-[#A8A29E] text-sm rounded-sm hover:border-white/30 transition-colors"
        >
          Cancel
        </button>
        {mode === "edit" && (
          <button
            type="button"
            onClick={handleDelete}
            disabled={loading}
            className="px-6 py-2.5 text-red-400/80 text-sm hover:text-red-400 transition-colors ml-auto"
          >
            Delete
          </button>
        )}
      </div>
    </form>
  );
}
