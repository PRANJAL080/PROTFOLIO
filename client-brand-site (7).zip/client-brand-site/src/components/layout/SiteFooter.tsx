import Link from "next/link";
import { CLIENT_NAME } from "@/lib/data";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/5 bg-[#0A0A0A]">
      <div className="max-w-6xl mx-auto px-6 py-16 md:py-20">
        <div className="grid md:grid-cols-3 gap-12 mb-14">
          <div className="space-y-4">
            <p className="text-[#F8F4EC] font-medium tracking-wide">
              {CLIENT_NAME}
            </p>
            <p className="text-[#A8A29E] text-xs tracking-[0.2em] uppercase">
              Author • Lyricist • Storyteller
            </p>
            <p className="text-[#A8A29E] text-sm leading-relaxed">
              Words become stories.
              <br />
              Stories become emotions.
            </p>
            <p className="hindi-text text-[#A8A29E]/60 text-sm pt-2">
              कुछ शब्द यहीं रह जाते हैं।
              <br />
              कुछ आपके साथ चले जाते हैं।
            </p>
          </div>

          <div className="space-y-4">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase">
              Explore
            </p>
            <nav className="flex flex-col gap-2">
              <Link href="/about" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">About</Link>
              <Link href="/songs" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">Songs</Link>
              <Link href="/books" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">Books</Link>
              <Link href="/story" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">Story</Link>
              <Link href="/services" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">Collaborate</Link>
              <Link href="/licensing" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">Licensing</Link>
            </nav>
          </div>

          <div className="space-y-4">
            <p className="text-[#C9A84C] text-xs tracking-widest uppercase">
              Connect
            </p>
            <nav className="flex flex-col gap-2">
              <Link href="/contact" className="text-[#A8A29E] text-sm hover:text-[#C9A84C] transition-colors">Contact</Link>
            </nav>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-[#A8A29E] text-xs">
          <p>© {new Date().getFullYear()} {CLIENT_NAME}. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="/privacy" className="hover:text-[#C9A84C] transition-colors">Privacy</Link>
            <Link href="/terms" className="hover:text-[#C9A84C] transition-colors">Terms</Link>
            <Link href="/licensing" className="hover:text-[#C9A84C] transition-colors">Licensing</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
