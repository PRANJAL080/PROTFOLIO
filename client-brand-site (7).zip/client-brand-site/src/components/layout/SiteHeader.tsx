"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { CLIENT_NAME } from "@/lib/data";

const navLinks = [
  { href: "/about", label: "About" },
  { href: "/songs", label: "Songs" },
  { href: "/books", label: "Books" },
  { href: "/story", label: "Story" },
  { href: "/services", label: "Collaborate" },
  { href: "/contact", label: "Contact" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
          scrolled
            ? "bg-[#0A0A0A]/90 backdrop-blur-md border-b border-white/5 py-3"
            : "bg-transparent py-5"
        )}
      >
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <Link
            href="/"
            className="text-[#F8F4EC] font-medium tracking-wide text-sm md:text-base hover:text-[#C9A84C] transition-colors"
          >
            {CLIENT_NAME}
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-[#A8A29E] text-sm tracking-wide hover:text-[#C9A84C] transition-colors"
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/songs/jayati-jay-narayana"
              className="ml-2 px-4 py-2 text-xs tracking-widest uppercase border border-[#C9A84C]/40 text-[#C9A84C] rounded-sm hover:bg-[#C9A84C]/10 transition-colors"
            >
              License a Song
            </Link>
          </nav>

          {/* Mobile toggle */}
          <button
            type="button"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
            className="lg:hidden flex flex-col gap-1.5 p-2"
          >
            <span
              className={cn(
                "block w-6 h-px bg-[#F8F4EC] transition-all",
                menuOpen && "rotate-45 translate-y-[3.5px]"
              )}
            />
            <span
              className={cn(
                "block w-6 h-px bg-[#F8F4EC] transition-all",
                menuOpen && "opacity-0"
              )}
            />
            <span
              className={cn(
                "block w-6 h-px bg-[#F8F4EC] transition-all",
                menuOpen && "-rotate-45 -translate-y-[3.5px]"
              )}
            />
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-[#0A0A0A] flex flex-col items-center justify-center gap-8 transition-all duration-500 lg:hidden",
          menuOpen
            ? "opacity-100 pointer-events-auto"
            : "opacity-0 pointer-events-none"
        )}
      >
        {navLinks.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            onClick={() => setMenuOpen(false)}
            className="text-2xl text-[#F8F4EC] hover:text-[#C9A84C] transition-colors"
          >
            {link.label}
          </Link>
        ))}
        <Link
          href="/songs/jayati-jay-narayana"
          onClick={() => setMenuOpen(false)}
          className="mt-4 px-6 py-3 border border-[#C9A84C]/50 text-[#C9A84C] tracking-widest uppercase text-sm"
        >
          License a Song
        </Link>
      </div>
    </>
  );
}
