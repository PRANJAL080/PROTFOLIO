import { NextRequest, NextResponse } from "next/server";
import { createSong, getSongs } from "@/lib/songs-store";

export async function GET() {
  const songs = await getSongs();
  return NextResponse.json(songs);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body.title || typeof body.title !== "string") {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }
    const song = await createSong(body);
    return NextResponse.json(song, { status: 201 });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Failed to create song" }, { status: 500 });
  }
}
