export const metadata = {
  title: "Contact",
  description: "Get in touch with Raj Bahadur Singh Chauhan.",
};

export default function ContactPage() {
  return (
    <main className="min-h-screen pt-28 pb-20 px-6">
      <div className="max-w-2xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="hindi-text text-3xl md:text-4xl text-[#C9A84C]">
            कुछ कहना है?
          </h1>
          <p className="text-[#A8A29E] text-lg">
            शायद उसे शब्दों की ज़रूरत हो।
          </p>
        </div>

        <form
          action="/api/contact"
          method="POST"
          className="space-y-6 border border-white/10 rounded-sm p-8 md:p-10 bg-gradient-to-br from-white/[0.02] to-transparent"
        >
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label htmlFor="name" className="text-xs tracking-widest uppercase text-[#A8A29E]">
                Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                className="w-full bg-transparent border border-white/15 rounded-sm px-4 py-3 text-[#F8F4EC] focus:outline-none focus:border-[#C9A84C]/60 transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="text-xs tracking-widest uppercase text-[#A8A29E]">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                className="w-full bg-transparent border border-white/15 rounded-sm px-4 py-3 text-[#F8F4EC] focus:outline-none focus:border-[#C9A84C]/60 transition-colors"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label htmlFor="phone" className="text-xs tracking-widest uppercase text-[#A8A29E]">
                Phone
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                className="w-full bg-transparent border border-white/15 rounded-sm px-4 py-3 text-[#F8F4EC] focus:outline-none focus:border-[#C9A84C]/60 transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="projectType" className="text-xs tracking-widest uppercase text-[#A8A29E]">
                Project Type
              </label>
              <select
                id="projectType"
                name="projectType"
                className="w-full bg-[#0A0A0A] border border-white/15 rounded-sm px-4 py-3 text-[#F8F4EC] focus:outline-none focus:border-[#C9A84C]/60 transition-colors"
              >
                <option value="Song Licensing">Song Licensing</option>
                <option value="Book">Book</option>
                <option value="Custom Song">Custom Song</option>
                <option value="Writing Collaboration">Writing Collaboration</option>
                <option value="Speaking / Event">Speaking / Event</option>
                <option value="General Enquiry">General Enquiry</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="subject" className="text-xs tracking-widest uppercase text-[#A8A29E]">
              Subject
            </label>
            <input
              type="text"
              id="subject"
              name="subject"
              className="w-full bg-transparent border border-white/15 rounded-sm px-4 py-3 text-[#F8F4EC] focus:outline-none focus:border-[#C9A84C]/60 transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="message" className="text-xs tracking-widest uppercase text-[#A8A29E]">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              rows={5}
              required
              className="w-full bg-transparent border border-white/15 rounded-sm px-4 py-3 text-[#F8F4EC] focus:outline-none focus:border-[#C9A84C]/60 transition-colors resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full md:w-auto px-10 py-3.5 bg-[#C9A84C] text-[#0A0A0A] font-medium tracking-wide rounded-sm hover:bg-[#A68B3D] transition-colors"
          >
            Send Message
          </button>

          <p className="text-[#A8A29E]/50 text-xs">
            Submissions are stored for admin review. Full API + database wiring is prepared.
          </p>
        </form>
      </div>
    </main>
  );
}
