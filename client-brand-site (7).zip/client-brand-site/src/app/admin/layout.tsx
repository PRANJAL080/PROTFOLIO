import Link from "next/link";
import { CLIENT_NAME } from "@/lib/data";

const adminNav = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/songs", label: "Songs" },
  { href: "/admin/books", label: "Books" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/licensing", label: "Licensing" },
  { href: "/admin/enquiries", label: "Enquiries" },
  { href: "/admin/story", label: "Story" },
  { href: "/admin/homepage", label: "Homepage" },
  { href: "/admin/media", label: "Media" },
  { href: "/admin/seo", label: "SEO" },
  { href: "/admin/settings", label: "Settings" },
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F8F4EC] flex">
      {/* Sidebar */}
      <aside className="hidden md:flex w-56 flex-col border-r border-white/10 py-8 px-4 shrink-0">
        <div className="mb-10 px-2">
          <p className="text-[#C9A84C] text-xs tracking-widest uppercase mb-1">
            Admin
          </p>
          <p className="text-sm text-[#F8F4EC] truncate">{CLIENT_NAME}</p>
        </div>
        <nav className="flex flex-col gap-1">
          {adminNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-3 py-2 text-sm text-[#A8A29E] hover:text-[#C9A84C] hover:bg-white/5 rounded-sm transition-colors"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto pt-8 px-2">
          <Link
            href="/"
            className="text-xs text-[#A8A29E] hover:text-[#C9A84C] transition-colors"
          >
            ← View Site
          </Link>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="border-b border-white/10 px-6 py-4 flex items-center justify-between">
          <p className="text-sm text-[#A8A29E] md:hidden">Admin</p>
          <p className="text-xs text-[#A8A29E]/60">
            Raj Bahadur Singh Chauhan · Admin
          </p>
        </header>
        <main className="flex-1 p-6 md:p-10 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
