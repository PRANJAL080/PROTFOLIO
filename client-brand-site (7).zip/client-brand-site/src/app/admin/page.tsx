import Link from "next/link";
import { getSongs } from "@/lib/songs-store";
import { books } from "@/lib/data";

export const metadata = { title: "Admin Dashboard" };
export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const songs = await getSongs();
  const published = songs.filter((s) => s.published).length;

  const stats = [
    { label: "Total Songs", value: songs.length, href: "/admin/songs" },
    { label: "Live on Playlist", value: published, href: "/admin/songs" },
    { label: "Books", value: books.length, href: "/admin/books" },
    { label: "Orders", value: 0, href: "/admin/orders" },
    { label: "Licensing Requests", value: 0, href: "/admin/licensing" },
    { label: "Enquiries", value: 0, href: "/admin/enquiries" },
  ];

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-2xl text-[#F8F4EC] mb-1">Dashboard</h1>
        <p className="text-[#A8A29E] text-sm">
          Raj Bahadur Singh Chauhan — creative brand control
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat) => (
          <Link
            key={stat.label}
            href={stat.href}
            className="border border-white/10 rounded-sm p-5 bg-white/[0.02] hover:border-[#C9A84C]/30 transition-colors"
          >
            <p className="text-[#A8A29E] text-xs tracking-widest uppercase mb-2">
              {stat.label}
            </p>
            <p className="text-2xl text-[#F8F4EC]">{stat.value}</p>
          </Link>
        ))}
      </div>

      <div className="border border-white/10 rounded-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-[#C9A84C] text-sm tracking-widest uppercase">
            Playlist
          </h2>
          <Link href="/admin/songs/new" className="text-[#C9A84C] text-sm hover:underline">
            + Add song
          </Link>
        </div>
        {songs.length === 0 ? (
          <p className="text-[#A8A29E] text-sm">No songs yet.</p>
        ) : (
          <ul className="space-y-2">
            {songs.slice(0, 5).map((s) => (
              <li key={s.id} className="flex items-center justify-between text-sm">
                <span className="hindi-text text-[#F8F4EC]">
                  {String(s.trackNumber).padStart(2, "0")}. {s.title}
                </span>
                <span className="text-[#A8A29E]/50 text-xs">
                  {s.published ? "Live" : "Draft"}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
