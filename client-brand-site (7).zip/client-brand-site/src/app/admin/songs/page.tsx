import Link from "next/link";
import { getSongs } from "@/lib/songs-store";

export const metadata = { title: "Admin – Songs" };
export const dynamic = "force-dynamic";

export default async function AdminSongsPage() {
  const songs = await getSongs();

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#F8F4EC]">Songs / Playlist</h1>
          <p className="text-[#A8A29E] text-sm mt-1">
            {songs.length} track{songs.length !== 1 ? "s" : ""} · published songs appear on the public playlist
          </p>
        </div>
        <Link
          href="/admin/songs/new"
          className="inline-flex items-center justify-center px-5 py-2.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium rounded-sm hover:bg-[#A68B3D] transition-colors"
        >
          + Add Song
        </Link>
      </div>

      {songs.length === 0 ? (
        <div className="border border-dashed border-white/15 rounded-sm p-12 text-center">
          <p className="text-[#A8A29E] mb-4">No songs yet. Add your first track to the playlist.</p>
          <Link
            href="/admin/songs/new"
            className="text-[#C9A84C] text-sm border-b border-[#C9A84C]/40 pb-0.5"
          >
            Add Song →
          </Link>
        </div>
      ) : (
        <div className="border border-white/10 rounded-sm overflow-hidden">
          <div className="hidden md:grid grid-cols-[40px_1fr_100px_90px_80px_100px] gap-3 px-4 py-3 border-b border-white/10 text-[#A8A29E]/50 text-[11px] tracking-widest uppercase">
            <span>#</span>
            <span>Title</span>
            <span>Genre</span>
            <span>Status</span>
            <span>Live</span>
            <span className="text-right">Actions</span>
          </div>
          <ul className="divide-y divide-white/5">
            {songs.map((song) => (
              <li
                key={song.id}
                className="grid grid-cols-1 md:grid-cols-[40px_1fr_100px_90px_80px_100px] gap-2 md:gap-3 items-center px-4 py-4 hover:bg-white/[0.02]"
              >
                <span className="text-[#A8A29E]/50 text-sm tabular-nums">
                  {String(song.trackNumber).padStart(2, "0")}
                </span>
                <div className="min-w-0">
                  <p className="hindi-text text-[#F8F4EC] truncate">{song.title}</p>
                  <p className="text-[#A8A29E]/50 text-xs truncate md:hidden">
                    {song.genre} · {song.published ? "Published" : "Draft"}
                  </p>
                </div>
                <span className="hidden md:block text-[#A8A29E] text-xs truncate">
                  {song.genre}
                </span>
                <span className="hidden md:block text-[#A8A29E] text-xs">
                  {song.licenseStatus}
                </span>
                <span className="hidden md:block">
                  <span
                    className={`text-[11px] tracking-wider uppercase ${
                      song.published ? "text-emerald-500/80" : "text-[#A8A29E]/50"
                    }`}
                  >
                    {song.published ? "Live" : "Draft"}
                  </span>
                </span>
                <div className="flex justify-end gap-3 text-xs">
                  <Link
                    href={`/admin/songs/${song.id}`}
                    className="text-[#C9A84C] hover:underline"
                  >
                    Edit
                  </Link>
                  <Link
                    href={`/songs/${song.slug}`}
                    className="text-[#A8A29E] hover:text-[#C9A84C]"
                    target="_blank"
                  >
                    View
                  </Link>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
