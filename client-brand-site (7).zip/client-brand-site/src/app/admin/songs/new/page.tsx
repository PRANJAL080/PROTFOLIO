import Link from "next/link";
import { SongForm } from "@/components/admin/SongForm";

export const metadata = { title: "Admin – Add Song" };

export default function NewSongPage() {
  return (
    <div className="space-y-6">
      <div>
        <Link
          href="/admin/songs"
          className="text-[#A8A29E] text-xs tracking-widest uppercase hover:text-[#C9A84C] transition-colors"
        >
          ← Songs
        </Link>
        <h1 className="text-2xl text-[#F8F4EC] mt-3">Add Song to Playlist</h1>
        <p className="text-[#A8A29E] text-sm mt-1">
          New tracks appear on the public playlist when published.
        </p>
      </div>
      <SongForm mode="create" />
    </div>
  );
}
