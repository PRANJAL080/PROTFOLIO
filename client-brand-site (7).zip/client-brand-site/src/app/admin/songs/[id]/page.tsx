import Link from "next/link";
import { notFound } from "next/navigation";
import { SongForm } from "@/components/admin/SongForm";
import { getSongById } from "@/lib/songs-store";

export const dynamic = "force-dynamic";

export default async function EditSongPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const song = await getSongById(id);
  if (!song) notFound();

  return (
    <div className="space-y-6">
      <div>
        <Link
          href="/admin/songs"
          className="text-[#A8A29E] text-xs tracking-widest uppercase hover:text-[#C9A84C] transition-colors"
        >
          ← Songs
        </Link>
        <h1 className="text-2xl text-[#F8F4EC] mt-3 hindi-text">{song.title}</h1>
        <p className="text-[#A8A29E] text-sm mt-1">Edit playlist track</p>
      </div>
      <SongForm mode="edit" song={song} />
    </div>
  );
}
