export const metadata = { title: "Privacy" };

export default function PrivacyPage() {
  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-2xl text-[#F8F4EC]">Privacy</h1>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          This website collects only the information you voluntarily provide
          through contact and licensing forms — typically your name, email,
          phone number and message. This information is used solely to respond
          to your enquiry and is not sold or shared with third parties for
          marketing purposes.
        </p>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          Payment processing, when available, is handled by Razorpay. Please
          refer to Razorpay&apos;s privacy policy for details on payment data.
        </p>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          For any privacy-related questions, please use the contact form.
        </p>
      </div>
    </main>
  );
}
