export const metadata = {
  title: "The Story",
  description: "The quiet journey of words — from first feeling to finished form.",
};

const stages = [
  {
    label: "शुरुआत",
    title: "Beginning",
    body: "हर लेखन यात्रा किसी बड़ी घोषणा से शुरू नहीं होती। कभी-कभी वह बस एक विचार होता है जिसे मन बार-बार वापस बुलाता है।",
  },
  {
    label: "पहले शब्द",
    title: "First Words",
    body: "फिर शब्दों ने जगह बनानी शुरू की—कागज़ पर, मन में, और उन भावनाओं के बीच जिन्हें कहना आसान नहीं था।",
  },
  {
    label: "लेखन की दुनिया",
    title: "The World of Writing",
    body: "धीरे-धीरे लेखन सिर्फ़ एक आदत नहीं रहा। वह एक जगह बन गया—जहाँ अनुभव, स्मृति और कल्पना एक साथ बैठ सकते थे।",
  },
  {
    label: "गीत",
    title: "Songs",
    body: "जब शब्दों में लय आई, तो कुछ भाव गीतों की ओर चले गए। कुछ रचनाएँ सुनने के लिए बनीं, कुछ सिर्फ़ महसूस करने के लिए।",
  },
  {
    label: "किताबें",
    title: "Books",
    body: "और जब किसी विचार को एक पंक्ति से अधिक जगह चाहिए थी, तो पन्ने खुलते गए। कुछ कहानियाँ लंबे समय तक साथ चलने के लिए लिखी जाती हैं।",
  },
  {
    label: "आज",
    title: "Today",
    body: "आज लेखन किसी एक रूप तक सीमित नहीं है। गीत हैं, कहानियाँ हैं, किताबें हैं—और अभी लिखे जाने वाले बहुत से शब्द हैं।",
  },
  {
    label: "आगे",
    title: "What Comes Next",
    body: "शायद अगली कहानी अभी लिखी नहीं गई। शायद अगला गीत अभी अपनी पहली पंक्ति तलाश रहा है।",
  },
];

export default function StoryPage() {
  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-20 space-y-6">
          <h1 className="hindi-text text-3xl md:text-4xl text-[#C9A84C] leading-snug">
            हर लेखक के पीछे एक कहानी होती है।
          </h1>
          <p className="hindi-text text-[#A8A29E] text-lg leading-relaxed max-w-xl mx-auto">
            लेकिन हर कहानी सार्वजनिक नहीं होती।
            <br />
            कुछ कहानियाँ धीरे-धीरे शब्दों में अपना रास्ता बनाती हैं।
          </p>
        </div>

        <div className="relative">
          <div className="absolute left-[7px] md:left-1/2 top-2 bottom-2 w-px bg-white/10 md:-translate-x-1/2" />

          <div className="space-y-16">
            {stages.map((stage, i) => (
              <div
                key={stage.title}
                className={`relative flex ${
                  i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                <div className="absolute left-[7px] md:left-1/2 w-3.5 h-3.5 rounded-full bg-[#C9A84C] -translate-x-1/2 mt-1.5 z-10 ring-4 ring-[#0A0A0A]" />

                <div
                  className={`ml-10 md:ml-0 md:w-1/2 ${
                    i % 2 === 0 ? "md:pr-14 md:text-right" : "md:pl-14"
                  }`}
                >
                  <p className="text-[#C9A84C] text-xs tracking-[0.2em] uppercase mb-1">
                    {stage.label}
                  </p>
                  <h2 className="text-[#F8F4EC] text-xl mb-3">{stage.title}</h2>
                  <p className="hindi-text text-[#A8A29E] leading-relaxed">
                    {stage.body}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-24 pt-12 border-t border-white/5">
          <p className="hindi-text text-[#A8A29E]/80 text-lg mb-6">
            कुछ शब्द अभी भी लिखे जाने बाकी हैं।
          </p>
          <a
            href="/contact"
            className="inline-block px-8 py-3.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium tracking-wide rounded-sm hover:bg-[#A68B3D] transition-colors"
          >
            बात शुरू करें
          </a>
        </div>
      </div>
    </main>
  );
}
