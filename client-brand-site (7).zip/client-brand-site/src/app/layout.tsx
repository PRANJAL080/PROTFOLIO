import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { SiteFooter } from "@/components/layout/SiteFooter";

export const metadata: Metadata = {
  title: {
    default: "Raj Bahadur Singh Chauhan | Author • Lyricist • Storyteller",
    template: "%s | Raj Bahadur Singh Chauhan",
  },
  description:
    "Words become stories. Stories become emotions. Premium personal brand of an Indian Author, Lyricist and Storyteller.",
  openGraph: {
    type: "website",
    locale: "en_IN",
    siteName: "Raj Bahadur Singh Chauhan",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#0A0A0A] text-[#F8F4EC] antialiased flex flex-col">
        <div className="grain" aria-hidden="true" />
        <SiteHeader />
        <div className="flex-1">{children}</div>
        <SiteFooter />
      </body>
    </html>
  );
}
