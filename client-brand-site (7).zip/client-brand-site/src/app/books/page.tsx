import Link from "next/link";

export const metadata = {
  title: "Books",
  description: "Stories written to be held, read, and returned to.",
};

export default function BooksPage() {
  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16 space-y-5">
          <h1 className="hindi-text text-3xl md:text-4xl text-[#F8F4EC] leading-snug">
            कहानियाँ जो पन्नों से आगे जाती हैं।
          </h1>
          <p className="text-[#A8A29E] max-w-md mx-auto">
            Some stories are written to be read.
            <br />
            Some are written to be remembered.
          </p>
        </div>

        <div className="border border-white/10 rounded-sm overflow-hidden">
          <div className="p-12 md:p-20 text-center bg-gradient-to-b from-white/[0.02] to-transparent">
            <p className="text-[#C9A84C] text-xs tracking-[0.3em] uppercase mb-5">
              The Library
            </p>
            <h2 className="editorial-display text-2xl md:text-3xl text-[#F8F4EC] mb-4">
              An evolving collection
            </h2>
            <p className="text-[#A8A29E] text-sm max-w-sm mx-auto leading-relaxed mb-12">
              Stories, reflections and books — written to be held, read, and
              returned to. New titles will appear here as they are published.
            </p>

            <div className="inline-block border border-[#C9A84C]/20 rounded-sm px-10 py-8 bg-[#C9A84C]/[0.03]">
              <p className="text-[#C9A84C] text-sm tracking-wide mb-2">
                The Next Story
              </p>
              <p className="text-[#A8A29E] text-xs leading-relaxed">
                Coming soon from the author&apos;s desk
              </p>
            </div>
          </div>
        </div>

        <div className="text-center mt-16 space-y-4">
          <p className="text-[#A8A29E] text-sm">
            Interested in a particular kind of story, or would like to be
            notified when the first book arrives?
          </p>
          <Link
            href="/contact?type=Book"
            className="inline-block text-[#C9A84C] text-sm tracking-widest uppercase border-b border-[#C9A84C]/40 pb-1 hover:border-[#C9A84C] transition-colors"
          >
            Get in Touch →
          </Link>
        </div>
      </div>
    </main>
  );
}
