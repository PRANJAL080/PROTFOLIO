import Image from "next/image";
import Link from "next/link";
import { CLIENT_NAME } from "@/lib/data";

export const metadata = {
  title: "About",
  description: "The creative world of words, songs, stories and silence.",
};

export default function AboutPage() {
  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="grid md:grid-cols-[260px_1fr] gap-12 md:gap-16 items-start">
          <div className="relative aspect-[3/4] overflow-hidden border border-[#C9A84C]/20 shadow-xl shadow-black/40">
            <Image
              src="/portrait.png"
              alt={CLIENT_NAME}
              fill
              className="object-cover object-top"
              sizes="260px"
              priority
            />
          </div>

          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="hindi-text text-2xl md:text-3xl text-[#C9A84C] leading-snug">
                लेखक होना सिर्फ़ लिखना नहीं है।
                <br />
                देखना भी है।
                <br />
                महसूस करना भी है।
                <br />
                और उन भावनाओं को शब्द देना भी है
                <br />
                जिन्हें अक्सर हम अपने भीतर ही रखते हैं।
              </h1>
              <p className="text-[#F8F4EC]/80 text-lg leading-relaxed">
                यह मंच उन शब्दों का घर है।
              </p>
            </div>

            <div className="space-y-5 text-[#A8A29E] leading-relaxed">
              <p>
                Here, words take different forms — songs that carry emotion,
                stories that linger, poetry that stays quiet until it is needed,
                and books that ask to be held.
              </p>
              <p>
                Some works are written to be read in silence. Others find their
                way into melody. A few exist simply because the feeling could
                not remain unspoken.
              </p>
              <p>
                This space is for those who believe that the right words, at the
                right time, can still change the shape of a moment.
              </p>
            </div>

            <div className="pt-4 flex flex-wrap gap-6">
              <Link href="/songs" className="text-[#C9A84C] text-sm tracking-wide border-b border-[#C9A84C]/30 pb-0.5 hover:border-[#C9A84C] transition-colors">
                Songs
              </Link>
              <Link href="/books" className="text-[#C9A84C] text-sm tracking-wide border-b border-[#C9A84C]/30 pb-0.5 hover:border-[#C9A84C] transition-colors">
                Books
              </Link>
              <Link href="/story" className="text-[#C9A84C] text-sm tracking-wide border-b border-[#C9A84C]/30 pb-0.5 hover:border-[#C9A84C] transition-colors">
                The Story
              </Link>
              <Link href="/services" className="text-[#C9A84C] text-sm tracking-wide border-b border-[#C9A84C]/30 pb-0.5 hover:border-[#C9A84C] transition-colors">
                Collaborate
              </Link>
            </div>

            <p className="hindi-text text-[#A8A29E]/70 text-base pt-6 border-t border-white/5">
              यह कहानी अभी पूरी नहीं हुई है।
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
