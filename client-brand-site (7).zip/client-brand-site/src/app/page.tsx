import Image from "next/image";
import Link from "next/link";
import { CLIENT_NAME } from "@/lib/data";
import { getPublishedSongs } from "@/lib/songs-store";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const songs = await getPublishedSongs();
  const featured = songs[0];

  return (
    <main className="relative overflow-x-hidden">
      {/* ========== HERO ========== */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-28 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(201,168,76,0.07)_0%,_transparent_65%)]" />

        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <div className="space-y-3 mb-14">
            <p className="hindi-text text-2xl md:text-3xl text-[#C9A84C] tracking-wide">
              शब्द...
            </p>
            <p className="hindi-text text-xl md:text-2xl text-[#F8F4EC]/75">
              कभी कहानी बन जाते हैं।
            </p>
            <p className="hindi-text text-xl md:text-2xl text-[#F8F4EC]/75">
              कभी गीत।
            </p>
            <p className="hindi-text text-xl md:text-2xl text-[#F8F4EC]/90">
              और कभी...
              <br />
              <span className="text-[#C9A84C]">किसी के दिल की आवाज़।</span>
            </p>
          </div>

          {/* Editorial portrait */}
          <div className="relative mx-auto w-44 h-56 md:w-52 md:h-64 mb-10">
            <div className="absolute -inset-3 bg-gradient-to-b from-[#C9A84C]/15 to-[#6B2D3C]/10 blur-2xl rounded-sm" />
            <div className="relative w-full h-full overflow-hidden border border-[#C9A84C]/25 shadow-2xl shadow-black/60">
              <Image
                src="/portrait.png"
                alt={`${CLIENT_NAME} — Author, Lyricist, Storyteller`}
                fill
                className="object-cover object-top"
                priority
                sizes="(max-width: 768px) 176px, 208px"
              />
            </div>
          </div>

          <div className="space-y-3 mb-6">
            <h1 className="editorial-display text-3xl md:text-5xl font-semibold tracking-tight text-[#F8F4EC]">
              {CLIENT_NAME}
            </h1>
            <p className="text-[#A8A29E] text-xs md:text-sm tracking-[0.28em] uppercase">
              Author • Lyricist • Storyteller
            </p>
          </div>

          <p className="text-[#F8F4EC]/65 text-base md:text-lg leading-relaxed mb-10">
            Words become stories.
            <br />
            Stories become emotions.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="#world"
              className="px-8 py-3.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium tracking-wide rounded-sm hover:bg-[#A68B3D] transition-colors"
            >
              मेरी दुनिया में आइए
            </Link>
            <Link
              href="/songs"
              className="px-8 py-3.5 border border-[#C9A84C]/40 text-[#C9A84C] text-sm font-medium tracking-wide rounded-sm hover:bg-[#C9A84C]/10 hover:border-[#C9A84C] transition-colors"
            >
              Explore the Words
            </Link>
          </div>
        </div>

        <p className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[#A8A29E]/50 text-xs tracking-[0.2em] uppercase">
          Scroll to enter the story
        </p>
      </section>

      {/* ========== INTRODUCTION ========== */}
      <section className="py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-3xl mx-auto text-center space-y-10">
          <h2 className="hindi-text text-2xl md:text-4xl text-[#C9A84C] leading-snug">
            शब्द मेरे हैं,
            <br />
            एहसास शायद आपके भी हों।
          </h2>

          <div className="space-y-6 text-left max-w-2xl mx-auto">
            <p className="hindi-text text-[#F8F4EC]/80 text-lg leading-relaxed">
              हर शब्द की अपनी एक यात्रा होती है।
              कभी वह किसी अनुभव से जन्म लेता है,
              कभी किसी रिश्ते से,
              कभी किसी सवाल से,
              और कभी उस एहसास से जिसे कहना आसान नहीं होता।
            </p>
            <p className="hindi-text text-[#F8F4EC]/80 text-lg leading-relaxed">
              यहीं से लेखन शुरू होता है।
              कुछ शब्द पन्नों पर ठहर जाते हैं।
              कुछ धुनों में ढल जाते हैं।
              और कुछ सीधे किसी के दिल तक पहुँच जाते हैं।
            </p>
            <p className="text-[#A8A29E] leading-relaxed">
              Writing is not simply the act of putting thoughts on a page. It is
              the process of giving shape to something that was once only a
              feeling.
            </p>
          </div>

          <Link
            href="/story"
            className="inline-block text-[#C9A84C] text-sm tracking-widest uppercase border-b border-[#C9A84C]/40 pb-1 hover:border-[#C9A84C] transition-colors"
          >
            Read the Story →
          </Link>
        </div>
      </section>

      {/* ========== CREATIVE WORLD ========== */}
      <section id="world" className="py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-3">
            <h2 className="hindi-text text-2xl md:text-3xl text-[#F8F4EC]">
              एक दुनिया,
              <br />
              जहाँ हर एहसास को शब्द मिलते हैं।
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            {[
              {
                href: "/songs",
                num: "01",
                hindi: "जो महसूस किया,\nवो गीत बन गया।",
                en: "Original lyrics shaped around emotion, imagery and the stories we carry within us.",
                cta: "Explore Songs",
              },
              {
                href: "/books",
                num: "02",
                hindi: "कुछ कहानियाँ पढ़ी नहीं जातीं,\nजी जाती हैं।",
                en: "Stories created to stay with you long after the final page.",
                cta: "Explore Books",
              },
              {
                href: "/story",
                num: "03",
                hindi: "हर शब्द के पीछे\nएक एहसास है।",
                en: "Poetry, reflections, narratives and words written simply because some thoughts deserve to exist.",
                cta: "Enter the Writing",
              },
              {
                href: "/services",
                num: "04",
                hindi: "आपकी कहानी,\nउनके शब्द।",
                en: "For ideas, memories and stories that need a voice.",
                cta: "Start a Conversation",
              },
            ].map((card) => (
              <Link
                key={card.num}
                href={card.href}
                className="group relative p-8 md:p-10 border border-white/10 rounded-sm bg-gradient-to-br from-white/[0.025] to-transparent hover:border-[#C9A84C]/35 transition-all duration-500 overflow-hidden"
              >
                <div className="absolute inset-0 bg-[#C9A84C]/[0.04] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative z-10">
                  <span className="text-[#C9A84C]/50 text-xs tracking-[0.25em]">
                    {card.num}
                  </span>
                  <h3 className="hindi-text text-xl md:text-2xl text-[#F8F4EC] mt-4 mb-4 whitespace-pre-line group-hover:text-[#C9A84C] transition-colors leading-snug">
                    {card.hindi}
                  </h3>
                  <p className="text-[#A8A29E] text-sm leading-relaxed mb-6">
                    {card.en}
                  </p>
                  <span className="text-[#C9A84C] text-sm tracking-wide opacity-70 group-hover:opacity-100 transition-opacity">
                    {card.cta} →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FEATURED SONG ========== */}
      {featured && (
        <section className="py-24 md:py-32 px-6 border-t border-white/5">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12 space-y-4">
              <p className="text-[#C9A84C]/70 text-xs tracking-[0.3em] uppercase">
                Featured Song
              </p>
              <h2 className="hindi-text text-3xl md:text-4xl text-[#F8F4EC]">
                {featured.title}
              </h2>
              <p className="hindi-text text-[#A8A29E] text-lg max-w-lg mx-auto leading-relaxed">
                कुछ गीत सिर्फ़ सुने नहीं जाते।
                <br />
                वे भीतर कहीं एक शांत जगह बना लेते हैं।
              </p>
            </div>

            <div className="border border-white/10 rounded-sm overflow-hidden">
              <div className="grid md:grid-cols-2">
                {/* Waveform panel */}
                <div className="bg-[#4A1F2A]/35 p-12 flex flex-col items-center justify-center min-h-[280px]">
                  <div className="flex items-end gap-1.5 h-16 mb-8">
                    {[38, 72, 52, 88, 44, 78, 58, 94, 48, 70, 62, 82, 50, 68].map(
                      (h, i) => (
                        <div
                          key={i}
                          className="wave-bar w-1.5 bg-[#C9A84C]/65 rounded-full"
                          style={{
                            height: `${h}%`,
                            animationDelay: `${i * 0.07}s`,
                          }}
                        />
                      )
                    )}
                  </div>
                  <p className="text-[#A8A29E] text-[11px] tracking-[0.2em] uppercase">
                    AI-generated audio rendition
                  </p>
                </div>

                {/* Info panel */}
                <div className="p-10 md:p-12 flex flex-col justify-center space-y-6">
                  <div>
                    <p className="text-[#C9A84C] text-sm mb-1">
                      Original Lyrics by {CLIENT_NAME}
                    </p>
                    <p className="text-[#A8A29E] text-sm leading-relaxed">
                      जयति जय नारायणा is presented here as a written lyrical
                      work, accompanied by an AI-generated audio rendition.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    {featured.sunoUrl && (
                    <a
                      href={featured.sunoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium rounded-sm hover:bg-[#A68B3D] transition-colors"
                    >
                      Listen on Suno
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" />
                      </svg>
                    </a>
                    )}
                    <Link
                      href={`/songs/${featured.slug}`}
                      className="px-5 py-2.5 border border-[#C9A84C]/40 text-[#C9A84C] text-sm rounded-sm hover:bg-[#C9A84C]/10 transition-colors"
                    >
                      View Song
                    </Link>
                    <Link
                      href="/licensing"
                      className="px-5 py-2.5 border border-white/15 text-[#A8A29E] text-sm rounded-sm hover:border-[#C9A84C]/40 hover:text-[#C9A84C] transition-colors"
                    >
                      License This Song
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ========== SONG COLLECTION TEASER ========== */}
      <section className="py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="space-y-3">
            <h2 className="hindi-text text-3xl md:text-4xl text-[#F8F4EC]">गीत</h2>
            <p className="hindi-text text-[#A8A29E] text-lg leading-relaxed">
              कुछ शब्द धुन तलाशते हैं।
              <br />
              कुछ धुनें शब्दों का इंतज़ार करती हैं।
            </p>
          </div>

          {featured && (
            <div className="border border-white/10 rounded-sm p-8 text-left max-w-xl mx-auto hover:border-[#C9A84C]/30 transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-[#C9A84C]/60 text-xs tracking-widest uppercase mb-2">
                    {featured.genre} · {featured.mood}
                  </p>
                  <h3 className="hindi-text text-2xl text-[#F8F4EC] mb-2">
                    {featured.title}
                  </h3>
                  <p className="text-[#A8A29E] text-sm">
                    Written by {CLIENT_NAME} · AI audio presentation
                  </p>
                </div>
                <Link
                  href={`/songs/${featured.slug}`}
                  className="shrink-0 text-[#C9A84C] text-sm tracking-wide"
                >
                  Listen →
                </Link>
              </div>
            </div>
          )}

          <p className="hindi-text text-[#A8A29E]/70 text-base pt-4">
            यह सफ़र अभी शुरू हुआ है।
            <br />
            कुछ और शब्द रास्ते में हैं।
          </p>

          <Link
            href="/songs"
            className="inline-block text-[#C9A84C] text-sm tracking-widest uppercase border-b border-[#C9A84C]/40 pb-1 hover:border-[#C9A84C] transition-colors"
          >
            All Songs →
          </Link>
        </div>
      </section>

      {/* ========== BOOKS ========== */}
      <section className="py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-4xl mx-auto text-center space-y-10">
          <div className="space-y-4">
            <h2 className="hindi-text text-2xl md:text-3xl text-[#F8F4EC]">
              कहानियाँ जो पन्नों से आगे जाती हैं।
            </h2>
            <p className="text-[#A8A29E] max-w-md mx-auto">
              Some stories are written to be read.
              <br />
              Some are written to be remembered.
            </p>
          </div>

          <div className="border border-white/10 rounded-sm p-12 md:p-16 bg-gradient-to-b from-white/[0.02] to-transparent">
            <p className="text-[#C9A84C] text-xs tracking-[0.3em] uppercase mb-4">
              The Library
            </p>
            <h3 className="editorial-display text-2xl md:text-3xl text-[#F8F4EC] mb-4">
              An evolving collection
            </h3>
            <p className="text-[#A8A29E] text-sm max-w-sm mx-auto leading-relaxed mb-8">
              Stories, reflections and books — written to be held, read, and
              returned to.
            </p>
            <div className="inline-block border border-dashed border-[#C9A84C]/25 rounded-sm px-8 py-6">
              <p className="text-[#C9A84C]/80 text-sm tracking-wide mb-1">
                The Next Story
              </p>
              <p className="text-[#A8A29E] text-xs">
                Coming soon from the author&apos;s desk
              </p>
            </div>
          </div>

          <Link
            href="/books"
            className="inline-block text-[#C9A84C] text-sm tracking-widest uppercase border-b border-[#C9A84C]/40 pb-1 hover:border-[#C9A84C] transition-colors"
          >
            Enter the Library →
          </Link>
        </div>
      </section>

      {/* ========== LICENSING ========== */}
      <section className="py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <h2 className="hindi-text text-2xl md:text-3xl text-[#F8F4EC] leading-snug">
            अगर इन शब्दों में
            <br />
            आपको अपनी कहानी सुनाई देती है...
          </h2>
          <p className="text-[#A8A29E]">Some words are meant to travel further.</p>
          <p className="text-[#A8A29E]/80 text-sm max-w-lg mx-auto leading-relaxed">
            Selected original lyrical works may be made available for licensing
            for personal, commercial or exclusive creative use, subject to the
            terms attached to each work.
          </p>
          <Link
            href="/licensing"
            className="inline-block px-8 py-3.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium tracking-wide rounded-sm hover:bg-[#A68B3D] transition-colors"
          >
            Request a License
          </Link>
        </div>
      </section>

      {/* ========== FINAL CTA ========== */}
      <section className="py-24 md:py-32 px-6 border-t border-white/5">
        <div className="max-w-xl mx-auto text-center space-y-6">
          <h2 className="hindi-text text-2xl md:text-3xl text-[#F8F4EC]">
            कुछ कहना है?
          </h2>
          <p className="text-[#A8A29E]">
            शायद उसे शब्दों की ज़रूरत हो।
          </p>
          <Link
            href="/contact"
            className="inline-block px-10 py-3.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium tracking-wide rounded-sm hover:bg-[#A68B3D] transition-colors"
          >
            बात शुरू करें
          </Link>
        </div>
      </section>
    </main>
  );
}
