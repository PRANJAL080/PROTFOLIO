import Link from "next/link";
import { CLIENT_NAME } from "@/lib/data";
import { getPublishedSongs } from "@/lib/songs-store";

export const metadata = {
  title: "Songs | मेरे गीत",
  description: "Original lyrics by Raj Bahadur Singh Chauhan — a living playlist of written works.",
};

export const dynamic = "force-dynamic";

export default async function SongsPage() {
  const songs = await getPublishedSongs();

  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="mb-12 space-y-4">
          <p className="text-[#C9A84C]/70 text-xs tracking-[0.3em] uppercase">
            Playlist
          </p>
          <h1 className="hindi-text text-3xl md:text-5xl text-[#C9A84C]">
            मेरे गीत
          </h1>
          <p className="hindi-text text-[#A8A29E] text-lg leading-relaxed">
            कुछ शब्द धुन तलाशते हैं।
            <br />
            कुछ धुनें शब्दों का इंतज़ार करती हैं।
          </p>
          <p className="text-[#A8A29E]/70 text-sm">
            Original lyrics by {CLIENT_NAME}
            {songs.length > 0 && (
              <span>
                {" "}
                · {songs.length} {songs.length === 1 ? "track" : "tracks"}
              </span>
            )}
          </p>
        </div>

        <div className="border border-white/10 rounded-sm overflow-hidden">
          <div className="hidden sm:grid grid-cols-[48px_1fr_120px_100px] gap-4 px-5 py-3 border-b border-white/10 text-[#A8A29E]/50 text-[11px] tracking-widest uppercase">
            <span>#</span>
            <span>Title</span>
            <span>Genre</span>
            <span className="text-right">Status</span>
          </div>

          {songs.length === 0 ? (
            <div className="px-6 py-16 text-center">
              <p className="hindi-text text-[#A8A29E] text-base leading-relaxed">
                यह सफ़र अभी शुरू हुआ है।
                <br />
                कुछ और शब्द रास्ते में हैं।
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-white/5">
              {songs.map((song, index) => (
                <li key={song.id}>
                  <Link
                    href={`/songs/${song.slug}`}
                    className="group grid grid-cols-[48px_1fr] sm:grid-cols-[48px_1fr_120px_100px] gap-4 items-center px-5 py-4 hover:bg-white/[0.03] transition-colors"
                  >
                    <span className="text-[#A8A29E]/50 text-sm tabular-nums group-hover:text-[#C9A84C] transition-colors">
                      {String(song.trackNumber || index + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0">
                      <p className="hindi-text text-[#F8F4EC] text-base md:text-lg truncate group-hover:text-[#C9A84C] transition-colors">
                        {song.title}
                      </p>
                      <p className="text-[#A8A29E]/60 text-xs mt-0.5 truncate">
                        {song.mood || "Original lyric"}
                        {song.sunoUrl && " · AI audio"}
                      </p>
                    </div>
                    <span className="hidden sm:block text-[#A8A29E] text-xs truncate">
                      {song.genre}
                    </span>
                    <span className="hidden sm:block text-right text-[11px] tracking-wider uppercase text-[#A8A29E]/50">
                      {song.licenseStatus}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>

        {songs.length > 0 && (
          <p className="hindi-text text-center text-[#A8A29E]/60 text-sm mt-12 leading-relaxed">
            यह सफ़र अभी शुरू हुआ है।
            <br />
            कुछ और शब्द रास्ते में हैं।
          </p>
        )}
      </div>
    </main>
  );
}
