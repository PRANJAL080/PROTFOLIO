import Link from "next/link";
import { notFound } from "next/navigation";
import { CLIENT_NAME } from "@/lib/data";
import { getPublishedSongs, getSongBySlug } from "@/lib/songs-store";

export const dynamic = "force-dynamic";

export default async function SongDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const song = await getSongBySlug(slug);
  if (!song || !song.published) notFound();

  const allSongs = await getPublishedSongs();
  const related = allSongs.filter((s) => s.id !== song.id).slice(0, 3);

  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <article className="max-w-3xl mx-auto space-y-14">
        <div className="text-center space-y-5">
          <p className="text-[#C9A84C]/70 text-xs tracking-[0.3em] uppercase">
            Track {String(song.trackNumber).padStart(2, "0")} · Original Lyric
          </p>
          <h1 className="hindi-text text-4xl md:text-5xl text-[#F8F4EC]">
            {song.title}
          </h1>
          <p className="hindi-text text-[#A8A29E] text-lg">
            एक भाव,
            <br />
            जिसे शब्दों ने आकार दिया।
          </p>
        </div>

        {song.description && (
          <div className="border border-white/10 rounded-sm p-8 md:p-10">
            <p className="text-[#F8F4EC]/85 text-lg leading-relaxed">
              {song.description}
            </p>
          </div>
        )}

        <div className="grid sm:grid-cols-2 gap-6 text-sm">
          <div className="space-y-1">
            <p className="text-[#A8A29E]/60 text-xs tracking-widest uppercase">Genre</p>
            <p className="text-[#F8F4EC]">{song.genre}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[#A8A29E]/60 text-xs tracking-widest uppercase">Mood</p>
            <p className="text-[#F8F4EC]">{song.mood || "—"}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[#A8A29E]/60 text-xs tracking-widest uppercase">Written by</p>
            <p className="text-[#F8F4EC]">{CLIENT_NAME}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[#A8A29E]/60 text-xs tracking-widest uppercase">Audio</p>
            <p className="text-[#F8F4EC]">
              {song.sunoUrl ? "AI-generated rendition" : "Lyrics only"}
            </p>
          </div>
        </div>

        {song.sunoUrl && (
          <div className="border border-white/10 rounded-sm overflow-hidden">
            <div className="bg-[#4A1F2A]/30 p-10 flex flex-col items-center gap-6">
              <div className="flex items-end gap-1.5 h-14">
                {[40, 70, 55, 90, 45, 80, 60, 95, 50, 75, 65, 85].map((h, i) => (
                  <div
                    key={i}
                    className="wave-bar w-1.5 bg-[#C9A84C]/70 rounded-full"
                    style={{ height: `${h}%`, animationDelay: `${i * 0.07}s` }}
                  />
                ))}
              </div>
              <p className="text-[#A8A29E] text-[11px] tracking-[0.2em] uppercase">
                AI-generated audio rendition
              </p>
              <a
                href={song.sunoUrl || "#"}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-7 py-3 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium rounded-sm hover:bg-[#A68B3D] transition-colors"
              >
                Listen on Suno
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" />
                </svg>
              </a>
            </div>
          </div>
        )}

        <div className="space-y-4">
          <h2 className="text-[#C9A84C] text-xs tracking-[0.25em] uppercase">Lyrics</h2>
          <div className="border border-white/10 rounded-sm p-8 md:p-10">
            {song.lyrics ? (
              <pre className="hindi-text text-[#F8F4EC]/85 whitespace-pre-wrap text-base leading-relaxed font-sans">
                {song.lyrics}
              </pre>
            ) : (
              <p className="hindi-text text-[#F8F4EC]/70 text-center leading-relaxed">
                The complete lyrical text will be published here by the author.
              </p>
            )}
          </div>
        </div>

        {song.licenseAvailable && (
          <div className="border border-[#C9A84C]/20 rounded-sm p-8 md:p-10 bg-[#C9A84C]/[0.04] text-center space-y-5">
            <h2 className="hindi-text text-xl md:text-2xl text-[#C9A84C]">
              इस गीत को अपनी कहानी का हिस्सा बनाइए
            </h2>
            <p className="text-[#A8A29E] text-sm max-w-md mx-auto">
              Original lyrics available for personal, commercial or exclusive
              licensing. Pricing on request.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link
                href={`/contact?type=Song+Licensing&song=${song.slug}`}
                className="px-6 py-3 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium rounded-sm hover:bg-[#A68B3D] transition-colors"
              >
                Request a License
              </Link>
              <Link
                href="/songs"
                className="px-6 py-3 border border-white/15 text-[#A8A29E] text-sm rounded-sm hover:border-[#C9A84C]/40 hover:text-[#C9A84C] transition-colors"
              >
                Back to Playlist
              </Link>
            </div>
          </div>
        )}

        {related.length > 0 && (
          <div className="space-y-4 pt-4">
            <h2 className="text-[#C9A84C] text-xs tracking-[0.25em] uppercase">
              More from the playlist
            </h2>
            <ul className="border border-white/10 rounded-sm divide-y divide-white/5">
              {related.map((s) => (
                <li key={s.id}>
                  <Link
                    href={`/songs/${s.slug}`}
                    className="flex items-center gap-4 px-5 py-4 hover:bg-white/[0.03] transition-colors"
                  >
                    <span className="text-[#A8A29E]/40 text-sm tabular-nums w-8">
                      {String(s.trackNumber).padStart(2, "0")}
                    </span>
                    <span className="hindi-text text-[#F8F4EC] flex-1">{s.title}</span>
                    <span className="text-[#A8A29E] text-xs">{s.genre}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </article>
    </main>
  );
}
