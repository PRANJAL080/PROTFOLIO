export const metadata = { title: "Terms" };

export default function TermsPage() {
  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-2xl text-[#F8F4EC]">Terms of Use</h1>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          All original written content on this website — including lyrics,
          poetry, stories and other literary works — remains the intellectual
          property of the author unless otherwise licensed in writing.
        </p>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          AI-generated audio presentations are provided for demonstration and
          emotional experience only. They do not constitute a claim of
          performance by the author.
        </p>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          Licensing of original lyrics is available by enquiry and subject to
          separate written agreement. Unauthorised commercial use of any
          material is not permitted.
        </p>
        <p className="text-[#A8A29E] text-sm leading-relaxed">
          Book purchases, when available, are subject to the terms displayed at
          the time of order.
        </p>
      </div>
    </main>
  );
}
