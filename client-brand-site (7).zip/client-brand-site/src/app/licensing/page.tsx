import Link from "next/link";
import { CLIENT_NAME } from "@/lib/data";
import { getPublishedSongs } from "@/lib/songs-store";

export const metadata = {
  title: "Song Licensing",
  description: "License original lyrics for personal, commercial or exclusive use.",
};

export const dynamic = "force-dynamic";

export default async function LicensingPage() {
  const songs = await getPublishedSongs();
  const licensable = songs.filter((s) => s.licenseAvailable);

  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16 space-y-5">
          <h1 className="hindi-text text-3xl md:text-4xl text-[#F8F4EC] leading-snug">
            अगर इन शब्दों में
            <br />
            आपको अपनी कहानी सुनाई देती है...
          </h1>
          <p className="text-[#A8A29E]">Some words are meant to travel further.</p>
          <p className="text-[#A8A29E]/80 text-sm max-w-lg mx-auto leading-relaxed">
            Selected original lyrical works by {CLIENT_NAME} may be made available
            for licensing for personal, commercial or exclusive creative use.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-16">
          {[
            { title: "Personal Use", desc: "For personal creative projects and non-commercial use where permitted." },
            { title: "Commercial Use", desc: "For approved commercial projects, productions, campaigns or other business use." },
            { title: "Exclusive Rights", desc: "For projects seeking exclusive licensing arrangements." },
          ].map((tier) => (
            <div key={tier.title} className="border border-white/10 rounded-sm p-6 bg-white/[0.02]">
              <h3 className="text-[#C9A84C] text-xs tracking-[0.2em] uppercase mb-3">{tier.title}</h3>
              <p className="text-[#A8A29E] text-sm leading-relaxed">{tier.desc}</p>
            </div>
          ))}
        </div>

        <div className="border border-white/10 rounded-sm overflow-hidden mb-12">
          <div className="px-6 py-4 border-b border-white/10">
            <h2 className="text-[#F8F4EC] text-sm tracking-wide">Available Works</h2>
          </div>
          {licensable.length === 0 ? (
            <div className="p-10 text-center text-[#A8A29E] text-sm">
              Licensing options will appear here as works are published.
            </div>
          ) : (
            <ul className="divide-y divide-white/5">
              {licensable.map((song) => (
                <li key={song.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="hindi-text text-xl text-[#F8F4EC] mb-1">{song.title}</h3>
                    <p className="text-[#A8A29E] text-sm">
                      {song.genre} · Original lyrics by {CLIENT_NAME}
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <Link href={`/songs/${song.slug}`} className="px-4 py-2 text-sm border border-white/15 text-[#A8A29E] rounded-sm hover:border-[#C9A84C]/40 hover:text-[#C9A84C] transition-colors">
                      View
                    </Link>
                    <Link href={`/contact?type=Song+Licensing&song=${song.slug}`} className="px-4 py-2 text-sm bg-[#C9A84C] text-[#0A0A0A] rounded-sm hover:bg-[#A68B3D] transition-colors">
                      Request Pricing
                    </Link>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </main>
  );
}
