import Link from "next/link";

export const metadata = {
  title: "Collaborate",
  description: "Custom lyrics, songwriting, poetry, stories and creative collaboration.",
};

const services = [
  {
    hindi: "आपकी कहानी, आपकी भावना।",
    title: "Custom Lyrics",
    description:
      "आपकी कहानी, आपकी भावना और आपके विचारों को मूल lyrics में ढालना।",
  },
  {
    hindi: "विचार से गीत तक।",
    title: "Songwriting",
    description:
      "एक विचार से गीत की पूरी lyrical identity तक — emotion, imagery और structure के साथ।",
  },
  {
    hindi: "जो कहना बाकी रह गया।",
    title: "Poetry",
    description:
      "ऐसी कविताएँ जो निजी क्षणों, मंच, प्रकाशन या विशेष अवसरों के लिए लिखी जा सकें।",
  },
  {
    hindi: "अनुभव को कथा बनाना।",
    title: "Story Writing",
    description:
      "विचारों और अनुभवों को narrative form देना — short stories से लेकर longer literary pieces तक।",
  },
  {
    hindi: "लंबे विचारों के लिए जगह।",
    title: "Book Writing",
    description:
      "लंबे विचारों को एक व्यवस्थित literary work में बदलने की creative collaboration।",
  },
  {
    hindi: "दृष्टि और शब्द।",
    title: "Creative Collaboration",
    description:
      "जब किसी project को शब्दों से अधिक — एक दृष्टि की आवश्यकता हो।",
  },
  {
    hindi: "अवधारणा से दिशा तक।",
    title: "Script / Concept",
    description:
      "किसी concept को कहानी, treatment या written creative direction में बदलना।",
  },
];

export default function ServicesPage() {
  return (
    <main className="min-h-screen pt-28 pb-24 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16 space-y-5">
          <h1 className="hindi-text text-3xl md:text-4xl text-[#C9A84C] leading-snug">
            आपके एहसास,
            <br />
            उनके शब्द।
          </h1>
          <p className="text-[#A8A29E] max-w-lg mx-auto leading-relaxed">
            हर project को सिर्फ़ content नहीं चाहिए होता।
            कभी उसे एक आवाज़ चाहिए होती है।
            एक कहानी। एक भावना।
            या एक ऐसी पंक्ति जिसे लोग भूलें नहीं।
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          {services.map((s) => (
            <div
              key={s.title}
              className="group border border-white/10 rounded-sm p-8 hover:border-[#C9A84C]/35 transition-all duration-300 bg-gradient-to-br from-white/[0.02] to-transparent"
            >
              <p className="hindi-text text-[#C9A84C]/90 text-base mb-3">
                {s.hindi}
              </p>
              <h2 className="text-[#F8F4EC] text-lg mb-2 group-hover:text-[#C9A84C] transition-colors">
                {s.title}
              </h2>
              <p className="hindi-text text-[#A8A29E] text-sm leading-relaxed">
                {s.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-16 space-y-5">
          <p className="text-[#A8A29E]">
            Ready to begin a conversation?
          </p>
          <Link
            href="/contact?type=Writing+Collaboration"
            className="inline-block px-10 py-3.5 bg-[#C9A84C] text-[#0A0A0A] text-sm font-medium tracking-wide rounded-sm hover:bg-[#A68B3D] transition-colors"
          >
            अपनी कहानी साझा करें
          </Link>
        </div>
      </div>
    </main>
  );
}
