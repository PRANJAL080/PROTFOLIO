export const CLIENT_NAME = "Raj Bahadur Singh Chauhan";

export type Song = {
  id: string;
  title: string;
  slug: string;
  genre: string;
  mood: string;
  description: string;
  lyricsPreview: string | null;
  lyrics: string | null;
  sunoUrl: string | null;
  cover: string | null;
  trackNumber: number;
  duration: string | null;
  licenseAvailable: boolean;
  licenseStatus: string;
  personalPrice: number | null;
  commercialPrice: number | null;
  exclusivePrice: number | null;
  featured: boolean;
  published: boolean;
  createdAt: string;
};

export const featuredSong: Song = {
  id: "1",
  title: "जयति जय नारायणा",
  slug: "jayati-jay-narayana",
  genre: "Devotional",
  mood: "Reverent, Peaceful",
  description:
    "A heartfelt devotional composition expressing reverence and inner devotion.",
  lyricsPreview: null,
  lyrics: null,
  sunoUrl: "https://suno.com/song/ddc87634-1f67-441c-9424-e5c8e754b441",
  cover: null,
  trackNumber: 1,
  duration: null,
  licenseAvailable: true,
  licenseStatus: "Available",
  personalPrice: null,
  commercialPrice: null,
  exclusivePrice: null,
  featured: true,
  published: true,
  createdAt: new Date().toISOString(),
};

export const songs: Song[] = [featuredSong];

export const books: {
  id: string;
  title: string;
  slug: string;
  description?: string;
  cover?: string;
  digitalPrice?: number | null;
  physicalPrice?: number | null;
  published: boolean;
}[] = [];
