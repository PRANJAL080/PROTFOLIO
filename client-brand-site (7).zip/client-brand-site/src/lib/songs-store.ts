import { promises as fs } from "fs";
import path from "path";
import type { Song } from "./data";

const DATA_PATH = path.join(process.cwd(), "src/data/songs.json");

export async function getSongs(): Promise<Song[]> {
  try {
    const raw = await fs.readFile(DATA_PATH, "utf-8");
    const songs = JSON.parse(raw) as Song[];
    return songs.sort((a, b) => a.trackNumber - b.trackNumber);
  } catch {
    return [];
  }
}

export async function getPublishedSongs(): Promise<Song[]> {
  const songs = await getSongs();
  return songs.filter((s) => s.published);
}

export async function getSongBySlug(slug: string): Promise<Song | null> {
  const songs = await getSongs();
  return songs.find((s) => s.slug === slug) ?? null;
}

export async function getSongById(id: string): Promise<Song | null> {
  const songs = await getSongs();
  return songs.find((s) => s.id === id) ?? null;
}

export async function saveSongs(songs: Song[]): Promise<void> {
  await fs.writeFile(DATA_PATH, JSON.stringify(songs, null, 2), "utf-8");
}

export function slugify(title: string): string {
  return title
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\u0900-\u097f\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80) || `song-${Date.now()}`;
}

export async function createSong(
  input: Partial<Song> & { title: string }
): Promise<Song> {
  const songs = await getSongs();
  const maxTrack = songs.reduce((m, s) => Math.max(m, s.trackNumber), 0);
  const song: Song = {
    id: String(Date.now()),
    title: input.title,
    slug: input.slug || slugify(input.title),
    genre: input.genre || "Uncategorized",
    mood: input.mood || "",
    description: input.description || "",
    lyricsPreview: input.lyricsPreview ?? null,
    lyrics: input.lyrics ?? null,
    sunoUrl: input.sunoUrl ?? null,
    cover: input.cover ?? null,
    trackNumber: input.trackNumber ?? maxTrack + 1,
    duration: input.duration ?? null,
    licenseAvailable: input.licenseAvailable ?? true,
    licenseStatus: input.licenseStatus || "Available",
    personalPrice: input.personalPrice ?? null,
    commercialPrice: input.commercialPrice ?? null,
    exclusivePrice: input.exclusivePrice ?? null,
    featured: input.featured ?? false,
    published: input.published ?? true,
    createdAt: new Date().toISOString(),
  };
  songs.push(song);
  await saveSongs(songs);
  return song;
}

export async function updateSong(
  id: string,
  input: Partial<Song>
): Promise<Song | null> {
  const songs = await getSongs();
  const idx = songs.findIndex((s) => s.id === id);
  if (idx === -1) return null;
  songs[idx] = { ...songs[idx], ...input, id: songs[idx].id };
  await saveSongs(songs);
  return songs[idx];
}

export async function deleteSong(id: string): Promise<boolean> {
  const songs = await getSongs();
  const filtered = songs.filter((s) => s.id !== id);
  if (filtered.length === songs.length) return false;
  await saveSongs(filtered);
  return true;
}
